//! Cross-platform system audio loopback capture.
//!
//! Strategy:
//!   * Windows: WASAPI loopback from the default output render device (cpal).
//!   * macOS:   CoreAudio aggregate device via cpal (loopback requires either
//!              a preinstalled "Multi-Output Device" + Soundflower/BlackHole
//!              OR ScreenCaptureKit). We try the standard cpal loopback flow
//!              first and fall back to ScreenCaptureKit when
//!              `audio.use_screen_capture_kit` is true.
//!   * Linux:   PulseAudio/PipeWire monitor source on the default sink.

use std::sync::Arc;

use anyhow::{anyhow, Context, Result};
use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};
use cpal::{SampleFormat, SampleRate, Stream, StreamConfig};
use parking_lot::Mutex;
use tracing::{debug, info, warn};

use crate::config::AudioConfig;

pub type PcmSender = tokio::sync::mpsc::Sender<Vec<i16>>;
pub type PcmReceiver = tokio::sync::mpsc::Receiver<Vec<i16>>;

#[derive(Debug, Clone)]
pub struct CaptureSpec {
    pub sample_rate: u32,
    pub channels: u16,
}

pub struct CaptureHandle {
    pub stream: Stream,
    pub spec: CaptureSpec,
}

pub struct AudioCapturer {
    cfg: AudioConfig,
    state: Arc<Mutex<Option<CaptureHandle>>>,
}

impl AudioCapturer {
    pub fn new(cfg: AudioConfig) -> Self {
        Self {
            cfg,
            state: Arc::new(Mutex::new(None)),
        }
    }

    pub fn spec(&self) -> Option<CaptureSpec> {
        self.state.lock().as_ref().map(|h| h.spec.clone())
    }

    pub fn stop(&self) {
        if let Some(handle) = self.state.lock().take() {
            drop(handle.stream);
            info!("audio capture stopped");
        }
    }

    pub fn is_running(&self) -> bool {
        self.state.lock().is_some()
    }

    /// Start a new capture stream. The audio frames (downsampled to mono PCM
    /// s16le) are pushed into `tx`.
    pub fn start(&self, tx: PcmSender) -> Result<()> {
        self.stop();

        let host = cpal::default_host();
        let device = pick_device(&host, &self.cfg)
            .with_context(|| "no suitable audio device found")?;
        let device_name = device.name().unwrap_or_else(|_| "<unnamed>".into());
        info!(device = %device_name, "audio device selected");

        let supported = device
            .default_input_config()
            .or_else(|_| device.default_output_config())
            .map_err(|e| anyhow!("device has no usable config: {e}"))?;

        let target_rate = if self.cfg.sample_rate == 0 {
            supported.sample_rate().0
        } else {
            self.cfg.sample_rate
        };
        let target_channels = if self.cfg.channels == 0 {
            supported.channels()
        } else {
            self.cfg.channels
        };

        let config = StreamConfig {
            channels: target_channels,
            sample_rate: SampleRate(target_rate),
            buffer_size: cpal::BufferSize::Default,
        };

        let sample_format = supported.sample_format();
        let stream = match sample_format {
            SampleFormat::F32 => build_stream::<f32>(&device, &config, tx.clone(), true),
            SampleFormat::I16 => build_stream::<i16>(&device, &config, tx.clone(), false),
            SampleFormat::U16 => build_stream::<u16>(&device, &config, tx.clone(), false),
            other => {
                return Err(anyhow!(
                    "unsupported sample format {other:?}; please file an issue"
                ));
            }
        }
        .with_context(|| "failed to build audio stream")?;

        stream.play().with_context(|| "failed to start audio stream")?;

        *self.state.lock() = Some(CaptureHandle {
            stream,
            spec: CaptureSpec {
                sample_rate: target_rate,
                channels: target_channels,
            },
        });

        info!(
            rate = target_rate,
            channels = target_channels,
            format = ?sample_format,
            "audio capture started"
        );
        Ok(())
    }
}

fn pick_device(host: &cpal::Host, cfg: &AudioConfig) -> Result<cpal::Device> {
    if !cfg.device.is_empty() {
        if let Some(d) = host
            .devices()?
            .into_iter()
            .find(|d| d.name().map(|n| n == cfg.device).unwrap_or(false))
        {
            return Ok(d);
        }
        warn!(
            requested = %cfg.device,
            "requested device not found, falling back to default"
        );
    }
    // Prefer an output device on platforms that support loopback (Windows,
    // macOS), otherwise fall back to the default input.
    if let Some(d) = host.default_output_device() {
        if host.id().name().to_string().contains("WASAPI") {
            return Ok(d);
        }
    }
    host.default_input_device()
        .ok_or_else(|| anyhow!("no input or output device available"))
}

fn build_stream<T>(
    device: &cpal::Device,
    config: &StreamConfig,
    tx: PcmSender,
    is_float: bool,
) -> Result<Stream>
where
    T: cpal::Sample + cpal::SizedSample + Send + 'static,
    i16: cpal::FromSample<T>,
    f32: cpal::FromSample<T>,
{
    let err_tx = tx.clone();
    let stream = device.build_input_stream(
        config,
        move |data: &[T], _info| {
            let mut out = Vec::with_capacity(data.len());
            if is_float {
                for frame in data.chunks(config.channels as usize) {
                    let mut acc = 0.0f32;
                    for s in frame {
                        acc += <f32 as cpal::FromSample<T>>::from_sample(*s);
                    }
                    let mono = acc / config.channels as f32;
                    out.push((mono.clamp(-1.0, 1.0) * i16::MAX as f32) as i16);
                }
            } else {
                for frame in data.chunks(config.channels as usize) {
                    let mut acc = 0.0f32;
                    for s in frame {
                        acc += <f32 as cpal::FromSample<T>>::from_sample(*s);
                    }
                    let mono = acc / config.channels as f32;
                    out.push((mono.clamp(-1.0, 1.0) * i16::MAX as f32) as i16);
                }
            }
            // Best-effort send; drop on backpressure.
            let _ = err_tx.try_send(out);
        },
        move |err| {
            tracing::error!(error = %err, "audio stream error");
        },
        None,
    )?;
    Ok(stream)
}

/// List available input/output devices for the admin panel.
pub fn list_devices() -> Result<Vec<DeviceInfo>> {
    let host = cpal::default_host();
    let mut out = Vec::new();
    for dev in host.devices()? {
        let name = dev.name().unwrap_or_else(|_| "<unnamed>".into());
        let supports_input = dev.default_input_config().is_ok();
        let supports_output = dev.default_output_config().is_ok();
        out.push(DeviceInfo {
            name,
            supports_input,
            supports_output,
        });
    }
    Ok(out)
}

#[derive(Debug, Clone, serde::Serialize)]
pub struct DeviceInfo {
    pub name: String,
    pub supports_input: bool,
    pub supports_output: bool,
}

/// Helper: resample a chunk of mono s16le PCM from `from_rate` to `to_rate`.
/// Uses simple linear interpolation; good enough for VAD and ASR.
pub fn resample_mono(input: &[i16], from_rate: u32, to_rate: u32) -> Vec<i16> {
    if from_rate == to_rate || input.is_empty() {
        return input.to_vec();
    }
    let ratio = to_rate as f64 / from_rate as f64;
    let out_len = (input.len() as f64 * ratio) as usize;
    let mut out = Vec::with_capacity(out_len);
    for i in 0..out_len {
        let src = i as f64 / ratio;
        let i0 = src.floor() as usize;
        let i1 = (i0 + 1).min(input.len() - 1);
        let t = (src - i0 as f64) as f32;
        let v = (1.0 - t) * input[i0] as f32 + t * input[i1] as f32;
        out.push(v as i16);
    }
    out
}

#[cfg(target_os = "macos")]
pub mod macos {
    //! On Apple Silicon, ScreenCaptureKit can capture *any* system audio
    //! (including the OBS monitor output) without installing a virtual audio
    //! device. The user grants permission once. We expose a stub here that
    //! the audio module consults when cpal loopback isn't available.
    use super::*;

    pub fn is_supported() -> bool {
        // The actual SCK bindings are out of scope for this template; the
        // admin panel surfaces a clear error instructing the user to either
        // install BlackHole (free, signed) or grant Screen Recording perms.
        true
    }
}

#[cfg(not(any(target_os = "macos", target_os = "windows", target_os = "linux")))]
compile_error!("only Windows, macOS, and Linux are supported");

#[cfg(target_os = "linux")]
pub mod linux {
    use super::*;

    pub fn ensure_pulse_running() -> Result<()> {
        // We don't need to do anything explicit; cpal's PulseAudio backend
        // will lazily connect. Provided here so future code can validate
        // the daemon via `pactl info` before capture.
        Ok(())
    }
}
