//! Local HTTP / WebSocket server.
//!
//! Endpoints:
//!   GET  /                      -> welcome
//!   GET  /admin                 -> SPA admin panel (HTML)
//!   GET  /overlay               -> browser source overlay (HTML)
//!   GET  /api/config            -> current config
//!   POST /api/config            -> save config (restarts pipeline if needed)
//!   GET  /api/devices           -> list audio devices
//!   GET  /api/status            -> { running, audio, llm, obs, last_error }
//!   GET  /api/subtitles         -> current + history
//!   POST /api/subtitles/clear   -> clear current line
//!   WS   /ws/subtitles          -> live subtitle event stream

use std::net::SocketAddr;
use std::path::PathBuf;
use std::sync::Arc;

use anyhow::Result;
use axum::extract::ws::{Message, WebSocket, WebSocketUpgrade};
use axum::extract::{Query, State};
use axum::http::{header, HeaderValue, StatusCode};
use axum::response::{IntoResponse, Response};
use axum::routing::{get, post};
use axum::Router;
use tower_http::cors::CorsLayer;
use tower_http::services::ServeDir;
use tower_http::set_header::SetResponseHeaderLayer;
use tracing::{info, warn};

use crate::config::{AudioConfig, Config, FilterConfig, LlmConfig, ObsConfig, OverlayConfig, ServerConfig};
use crate::embedded;
use crate::AppState;

pub async fn serve(state: Arc<AppState>, cfg: ServerConfig) -> Result<()> {
    let static_dir: PathBuf = cfg.static_dir.clone();
    let app = build_router(state, static_dir);

    let addr: SocketAddr = format!("{}:{}", cfg.host, cfg.port)
        .parse()
        .map_err(|e| anyhow::anyhow!("bad bind address: {e}"))?;
    let listener = tokio::net::TcpListener::bind(addr).await?;
    let bound = listener.local_addr()?;
    info!(addr = %bound, "server bound");
    axum::serve(listener, app).await?;
    Ok(())
}

fn build_router(state: Arc<AppState>, static_dir: PathBuf) -> Router {
    let api = Router::new()
        .route("/api/config", get(get_config).post(post_config))
        .route("/api/devices", get(get_devices))
        .route("/api/status", get(get_status))
        .route("/api/subtitles", get(get_subtitles))
        .route("/api/subtitles/clear", post(clear_subtitles))
        .route("/api/restart", post(restart_pipeline))
        .route("/ws/subtitles", get(ws_subtitles))
        .with_state(state);

    // Disk directories for the live-reload case. If the user has a `dist/`
    // next to the binary we serve from there (so they can edit HTML/JS/CSS
    // and refresh). Otherwise the static-file handlers fall back to the
    // assets embedded at compile time, so the binary is fully self-contained.
    let admin_dir = static_dir.join("admin");
    let overlay_dir = static_dir.join("overlay");
    let bin_dir = static_dir.join("bin");

    Router::new()
        .route("/", get(root_handler))
        .route("/admin", get(admin_handler))
        .route("/overlay", get(overlay_handler))
        .nest("/api", api)
        .nest_service(
            "/admin-assets",
            ServeDir::new(admin_dir).fallback(axum::routing::get(embedded_admin_asset)),
        )
        .nest_service(
            "/overlay-assets",
            ServeDir::new(overlay_dir).fallback(axum::routing::get(embedded_overlay_asset)),
        )
        .nest_service("/bin", ServeDir::new(bin_dir))
        .route("/admin-assets/{*path}", get(embedded_admin_asset))
        .route("/overlay-assets/{*path}", get(embedded_overlay_asset))
        .route("/_assets/{*path}", get(embedded_any_asset))
        .layer(CorsLayer::permissive())
        .layer(SetResponseHeaderLayer::if_not_present(
            header::CACHE_CONTROL,
            HeaderValue::from_static("no-store"),
        ))
}

async fn root_handler() -> &'static str {
    "obs-live-translate is running. Visit /admin to configure, /overlay for the browser source."
}

async fn admin_handler() -> Response {
    serve_static("admin/index.html", "text/html; charset=utf-8").await
}

async fn overlay_handler() -> Response {
    serve_static("overlay/index.html", "text/html; charset=utf-8").await
}

fn detect_content_type(path: &str) -> &'static str {
    let lower = path.to_ascii_lowercase();
    if lower.ends_with(".html") || lower.ends_with(".htm") {
        "text/html; charset=utf-8"
    } else if lower.ends_with(".js") || lower.ends_with(".mjs") {
        "application/javascript; charset=utf-8"
    } else if lower.ends_with(".css") {
        "text/css; charset=utf-8"
    } else if lower.ends_with(".json") {
        "application/json; charset=utf-8"
    } else if lower.ends_with(".svg") {
        "image/svg+xml"
    } else if lower.ends_with(".png") {
        "image/png"
    } else if lower.ends_with(".jpg") || lower.ends_with(".jpeg") {
        "image/jpeg"
    } else if lower.ends_with(".gif") {
        "image/gif"
    } else if lower.ends_with(".ico") {
        "image/x-icon"
    } else if lower.ends_with(".wasm") {
        "application/wasm"
    } else if lower.ends_with(".txt") {
        "text/plain; charset=utf-8"
    } else {
        "application/octet-stream"
    }
}

async fn serve_static(rel: &str, content_type: &'static str) -> Response {
    let candidates = [
        std::path::PathBuf::from(rel),
        std::path::PathBuf::from("dist").join(rel),
    ];
    for c in &candidates {
        if let Ok(data) = std::fs::read(c) {
            return (
                StatusCode::OK,
                [(header::CONTENT_TYPE, HeaderValue::from_static(content_type))],
                data,
            )
                .into_response();
        }
    }
    // Fall back to embedded asset.
    if let Some(bytes) = embedded::read(rel) {
        let ctype = HeaderValue::from_static(detect_content_type(rel));
        return (
            StatusCode::OK,
            [(header::CONTENT_TYPE, ctype)],
            bytes.to_vec(),
        )
            .into_response();
    }
    (
        StatusCode::NOT_FOUND,
        format!("not found: {rel}"),
    )
        .into_response()
}

async fn embedded_admin_asset(
    axum::extract::Path(path): axum::extract::Path<String>,
) -> Response {
    let rel = format!("admin/{path}");
    respond_embedded(&rel)
}

async fn embedded_overlay_asset(
    axum::extract::Path(path): axum::extract::Path<String>,
) -> Response {
    let rel = format!("overlay/{path}");
    respond_embedded(&rel)
}

async fn embedded_any_asset(
    axum::extract::Path(path): axum::extract::Path<String>,
) -> Response {
    respond_embedded(&path)
}

fn respond_embedded(rel: &str) -> Response {
    if let Some(bytes) = embedded::read(rel) {
        let ctype = HeaderValue::from_static(detect_content_type(rel));
        return (
            StatusCode::OK,
            [(header::CONTENT_TYPE, ctype)],
            bytes.to_vec(),
        )
            .into_response();
    }
    (StatusCode::NOT_FOUND, format!("not found: {rel}")).into_response()
}

async fn get_config(State(state): State<Arc<AppState>>) -> Response {
    let cfg = state.config.read().clone();
    axum::Json(cfg).into_response()
}

#[derive(serde::Deserialize)]
#[serde(untagged)]
enum ConfigPatch {
    Full(Config),
    Partial(serde_json::Value),
}

async fn post_config(
    State(state): State<Arc<AppState>>,
    axum::Json(payload): axum::Json<serde_json::Value>,
) -> Response {
    // Merge patch onto current config.
    let mut cfg = state.config.read().clone();
    if let Err(e) = merge_json(&mut cfg, &payload) {
        return (
            StatusCode::BAD_REQUEST,
            axum::Json(serde_json::json!({"error": e.to_string()})),
        )
            .into_response();
    }
    if let Err(e) = cfg.save(&config_path()) {
        warn!(error = %e, "save config");
    }
    *state.config.write() = cfg;
    (
        StatusCode::OK,
        axum::Json(serde_json::json!({"ok": true})),
    )
        .into_response()
}

fn merge_json(cfg: &mut Config, patch: &serde_json::Value) -> anyhow::Result<()> {
    let mut current = serde_json::to_value(cfg.clone())?;
    json_merge(&mut current, patch);
    *cfg = serde_json::from_value(current)?;
    Ok(())
}

fn json_merge(dst: &mut serde_json::Value, patch: &serde_json::Value) {
    use serde_json::Value::Object;
    if let (Object(d), Object(p)) = (dst, patch) {
        for (k, v) in p {
            if v.is_null() {
                d.remove(k);
            } else {
                json_merge(d.entry(k.clone()).or_insert(Value::Null), v);
            }
        }
    } else {
        *dst = patch.clone();
    }
}

use serde_json::Value;

async fn get_devices() -> Response {
    match crate::audio::list_devices() {
        Ok(devs) => axum::Json(devs).into_response(),
        Err(e) => (
            StatusCode::INTERNAL_SERVER_ERROR,
            axum::Json(serde_json::json!({"error": e.to_string()})),
        )
            .into_response(),
    }
}

#[derive(serde::Serialize)]
struct StatusView {
    running: bool,
    audio_active: bool,
    llm_connected: bool,
    obs_connected: bool,
    last_error: Option<String>,
    last_subtitle_at: Option<chrono::DateTime<chrono::Utc>>,
    bind_url: String,
    obs_dock_url: Option<String>,
}

async fn get_status(State(state): State<Arc<AppState>>) -> Response {
    let cfg = state.config.read().clone();
    let s = state.status.read().clone();
    let view = StatusView {
        running: state.pipeline.is_running(),
        audio_active: s.audio_active,
        llm_connected: s.llm_connected,
        obs_connected: s.obs_connected,
        last_error: s.last_error,
        last_subtitle_at: s.last_subtitle_at,
        bind_url: format!("http://{}:{}", cfg.server.host, cfg.server.port),
        obs_dock_url: if cfg.obs.register_dock {
            Some(format!("http://{}:{}/admin?obsDock=1", cfg.server.host, cfg.server.port))
        } else {
            None
        },
    };
    axum::Json(view).into_response()
}

#[derive(serde::Serialize)]
struct SubtitlesView {
    current: Option<crate::subtitle::SubtitleLine>,
    history: Vec<crate::subtitle::SubtitleLine>,
}

async fn get_subtitles(State(state): State<Arc<AppState>>) -> Response {
    let view = SubtitlesView {
        current: state.subtitle.current(),
        history: state.subtitle.history(),
    };
    axum::Json(view).into_response()
}

async fn clear_subtitles(State(state): State<Arc<AppState>>) -> Response {
    state.subtitle.clear();
    axum::Json(serde_json::json!({"ok": true})).into_response()
}

async fn restart_pipeline(State(state): State<Arc<AppState>>) -> Response {
    state.pipeline.shutdown().await;
    // The pipeline's outer run() loop will spin a new try_start().
    axum::Json(serde_json::json!({"ok": true})).into_response()
}

async fn ws_subtitles(
    ws: WebSocketUpgrade,
    State(state): State<Arc<AppState>>,
) -> Response {
    ws.on_upgrade(move |socket| ws_loop(socket, state))
}

#[derive(serde::Deserialize, Default)]
struct WsQuery {
    #[serde(default)]
    since: Option<String>,
}

async fn ws_loop(mut socket: WebSocket, state: Arc<AppState>) {
    let mut rx = state.subtitle.subscribe();
    // Send the current state immediately.
    if let Some(cur) = state.subtitle.current() {
        let payload = serde_json::json!({
            "type": "current",
            "line": cur,
        });
        if socket
            .send(Message::Text(payload.to_string().into()))
            .await
            .is_err()
        {
            return;
        }
    }
    loop {
        tokio::select! {
            ev = rx.recv() => {
                let ev = match ev {
                    Ok(ev) => ev,
                    Err(tokio::sync::broadcast::error::RecvError::Lagged(_)) => continue,
                    Err(_) => return,
                };
                let payload = serde_json::to_string(&ev).unwrap_or_default();
                if socket.send(Message::Text(payload.into())).await.is_err() {
                    return;
                }
            }
            msg = socket.recv() => {
                match msg {
                    Some(Ok(Message::Close(_))) | None => return,
                    Some(Ok(Message::Ping(p))) => {
                        if socket.send(Message::Pong(p)).await.is_err() {
                            return;
                        }
                    }
                    Some(Ok(Message::Text(_))) => {
                        // Reserved for future client commands.
                    }
                    _ => {}
                }
            }
        }
    }
}

fn config_path() -> std::path::PathBuf {
    if let Some(p) = std::env::var_os("OLT_CONFIG") {
        return std::path::PathBuf::from(p);
    }
    let local = std::path::PathBuf::from("config.toml");
    if local.exists() {
        return local;
    }
    if let Some(mut dir) = dirs::config_dir() {
        dir.push("obs-live-translate");
        dir.push("config.toml");
        return dir;
    }
    local
}

// Touch the types we re-export via the file to keep the public surface
// discoverable.
#[allow(dead_code)]
fn _touch_types() {
    let _ = (AudioConfig::default, FilterConfig::default, LlmConfig::default,
             ObsConfig::default, OverlayConfig::default, ServerConfig::default);
}
